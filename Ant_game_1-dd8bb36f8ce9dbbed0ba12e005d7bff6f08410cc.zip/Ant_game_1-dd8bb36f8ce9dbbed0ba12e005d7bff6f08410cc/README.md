# Ant_Game_1
Made with Construct 3, as an introductory school project

## Game Objective
Playing as an ant, steal as much food as possible. Avoid enemies and beat the time limit.
<!--(old) You play as an ant on a mission to steal food from a picnic. The objective of the game is to navigate obstacles, avoid being spotted by humans or other creatures, and collect as much food as possible before time runs out.-->

# How to Save the Project:
1: Open Github Desktop <br></br>
2: Click Fetch <br></br>
3: Save in Construct 3.<br></br>
4: Open Github Desktop<br></br>
5: Write a Summary. <br></br>
6: Click Commit<br></br>
7: Click Push <br></br>


